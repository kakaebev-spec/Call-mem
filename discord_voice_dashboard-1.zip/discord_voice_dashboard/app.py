import os
import asyncio
import threading
import secrets
from collections import deque
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from dotenv import load_dotenv
import discord

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY") or secrets.token_hex(32)
DASHBOARD_PASSWORD = os.getenv("DASHBOARD_PASSWORD", "")
BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "")
DEFAULT_GUILD_ID = os.getenv("GUILD_ID", "")
DEFAULT_CHANNEL_IDS = os.getenv("VOICE_CHANNEL_IDS", "")
LOGS = deque(maxlen=200)
bot_loop = None
bot_thread = None
bot = None
bot_ready = threading.Event()
bot_state = {"running": False, "connected": False, "bot_name": "Nicht verbunden", "guild": None, "voice_channel": None}
settings = {"guild_id": DEFAULT_GUILD_ID, "channel_ids": DEFAULT_CHANNEL_IDS, "interval": 180}
voice_task = None
stop_requested = False

def log(message, level="INFO"):
    from datetime import datetime
    LOGS.appendleft({"time": datetime.now().strftime("%H:%M:%S"), "level": level, "message": str(message)})

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

class DashboardBot(discord.Client):
    async def on_ready(self):
        bot_state["running"] = True
        bot_state["bot_name"] = f"{self.user} ({self.user.id})"
        log(f"Discord-Bot angemeldet: {self.user}", "SUCCESS")
        bot_ready.set()

    async def on_voice_state_update(self, member, before, after):
        if self.user and member.id == self.user.id:
            if after.channel:
                bot_state["connected"] = True
                bot_state["voice_channel"] = after.channel.name
                log(f"Voice-Verbindung: {after.channel.name}", "SUCCESS")
            else:
                bot_state["connected"] = False
                bot_state["voice_channel"] = None
                log("Bot ist nicht mehr in einem Voice-Channel", "WARN")

def run_bot_thread():
    global bot_loop, bot_thread, bot
    intents = discord.Intents.default()
    intents.guilds = True
    intents.voice_states = True
    bot = DashboardBot(intents=intents)
    bot_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(bot_loop)
    try:
        bot_loop.run_until_complete(bot.start(BOT_TOKEN))
    except Exception as exc:
        log(f"Bot-Fehler: {exc}", "ERROR")
    finally:
        bot_state["running"] = False
        bot_state["connected"] = False
        bot_state["bot_name"] = "Nicht verbunden"
        bot_ready.clear()
        try:
            bot_loop.close()
        except Exception:
            pass

def start_bot():
    global bot_thread
    if not BOT_TOKEN:
        log("DISCORD_BOT_TOKEN fehlt in der .env-Datei.", "ERROR")
        return False, "Bot-Token fehlt. Bitte .env konfigurieren."
    if bot_thread and bot_thread.is_alive():
        return False, "Der Bot läuft bereits."
    bot_ready.clear()
    bot_thread = threading.Thread(target=run_bot_thread, daemon=True)
    bot_thread.start()
    log("Starte offiziellen Discord-Bot ...")
    return True, "Bot wird gestartet."

def stop_bot():
    global bot_loop, bot
    if bot and bot_loop and bot_loop.is_running():
        future = asyncio.run_coroutine_threadsafe(bot.close(), bot_loop)
        try:
            future.result(timeout=8)
        except Exception as exc:
            log(f"Beim Stoppen: {exc}", "WARN")
        log("Bot gestoppt.", "WARN")
        return True, "Bot wird gestoppt."
    return False, "Der Bot läuft nicht."

async def join_voice(channel_id):
    if not bot or not bot.is_ready():
        raise RuntimeError("Der Bot ist nicht online.")
    guild_id = int(settings["guild_id"])
    guild = bot.get_guild(guild_id)
    if guild is None:
        raise RuntimeError("Server nicht gefunden. Ist der Bot auf dem Server?")
    channel = guild.get_channel(int(channel_id))
    if not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
        raise RuntimeError("Voice-Channel nicht gefunden oder falscher Channel-Typ.")
    existing = discord.utils.get(bot.voice_clients, guild=guild)
    if existing:
        if existing.channel.id == channel.id:
            return f"Bereits verbunden mit {channel.name}."
        await existing.move_to(channel)
    else:
        await channel.connect()
    bot_state["connected"] = True
    bot_state["voice_channel"] = channel.name
    log(f"Verbunden mit Voice-Channel: {channel.name}", "SUCCESS")
    return f"Verbunden mit {channel.name}."

async def leave_voice():
    if not bot or not bot.is_ready():
        raise RuntimeError("Der Bot ist nicht online.")
    for vc in list(bot.voice_clients):
        await vc.disconnect(force=True)
    bot_state["connected"] = False
    bot_state["voice_channel"] = None
    log("Voice-Verbindung getrennt.", "WARN")
    return "Voice-Verbindung getrennt."

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not DASHBOARD_PASSWORD:
            flash("Bitte zuerst DASHBOARD_PASSWORD in .env setzen.", "error")
        elif secrets.compare_digest(request.form.get("password", ""), DASHBOARD_PASSWORD):
            session["authenticated"] = True
            return redirect(url_for("index"))
        else:
            flash("Falsches Passwort.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    return render_template("index.html", settings=settings, state=bot_state,
                           token_configured=bool(BOT_TOKEN), password_configured=bool(DASHBOARD_PASSWORD))

@app.post("/settings")
@login_required
def save_settings():
    guild_id = request.form.get("guild_id", "").strip()
    channel_ids = request.form.get("channel_ids", "").strip()
    interval = request.form.get("interval", "180").strip()
    try:
        if guild_id and not guild_id.isdigit():
            raise ValueError("Server-ID muss numerisch sein.")
        parsed = [x.strip() for x in channel_ids.split(",") if x.strip()]
        if any(not x.isdigit() for x in parsed):
            raise ValueError("Channel-IDs müssen Zahlen sein und mit Komma getrennt werden.")
        interval_num = int(interval)
        if interval_num < 30 or interval_num > 3600:
            raise ValueError("Intervall muss zwischen 30 und 3600 Sekunden liegen.")
        settings.update(guild_id=guild_id, channel_ids=channel_ids, interval=interval_num)
        log("Einstellungen aktualisiert.")
        flash("Einstellungen gespeichert. Hinweis: Dieses Starterprojekt verbindet nur auf ausdrücklichen Klick.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.post("/bot/start")
@login_required
def bot_start():
    ok, message = start_bot()
    flash(message, "success" if ok else "error")
    return redirect(url_for("index"))

@app.post("/bot/stop")
@login_required
def bot_stop():
    ok, message = stop_bot()
    flash(message, "success" if ok else "error")
    return redirect(url_for("index"))

@app.post("/voice/join")
@login_required
def voice_join():
    channel_id = request.form.get("channel_id", "").strip()
    if not channel_id.isdigit() or not settings["guild_id"]:
        flash("Bitte gültige Server-ID und Voice-Channel-ID eintragen.", "error")
        return redirect(url_for("index"))
    if not bot_loop or not bot_loop.is_running():
        flash("Bitte zuerst den Bot starten.", "error")
        return redirect(url_for("index"))
    try:
        future = asyncio.run_coroutine_threadsafe(join_voice(channel_id), bot_loop)
        flash(future.result(timeout=20), "success")
    except Exception as exc:
        log(f"Voice-Fehler: {exc}", "ERROR")
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.post("/voice/leave")
@login_required
def voice_leave():
    if not bot_loop or not bot_loop.is_running():
        flash("Bot ist nicht online.", "error")
    else:
        try:
            future = asyncio.run_coroutine_threadsafe(leave_voice(), bot_loop)
            flash(future.result(timeout=20), "success")
        except Exception as exc:
            flash(str(exc), "error")
    return redirect(url_for("index"))

@app.get("/api/status")
@login_required
def api_status():
    return jsonify({"state": bot_state, "logs": list(LOGS)[:60]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
