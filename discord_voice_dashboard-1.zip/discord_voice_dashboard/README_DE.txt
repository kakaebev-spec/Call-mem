DISCORD VOICE DASHBOARD — INSTALLATION (Windows 11 + Render)

WICHTIG
- Dieses Projekt verwendet einen offiziellen Discord-BOT-Token, keine User-Tokens.
- Ein einzelner Bot verbindet nur den Bot selbst mit Voice. Es loggt nicht mehrere persönliche Accounts ein.
- Behandle DISCORD_BOT_TOKEN wie ein Passwort. Nicht in GitHub hochladen.
- Verwende das Dashboard nur für Server, auf denen du berechtigt bist.
- Dieses Starterprojekt startet/stoppt den Bot und erlaubt manuelles Voice-Join/Leave. Das gespeicherte Intervall wird angezeigt, aber keine automatische Rejoin-Schleife ausgeführt.

A) LOKAL AUF WINDOWS TESTEN
1. Python 3.11 oder 3.12 installieren.
2. ZIP entpacken und im Ordner den Datei-Explorer öffnen.
3. In die Adressleiste "cmd" schreiben und Enter drücken.
4. Befehle einzeln ausführen:
   py -m venv .venv
   .venv\Scripts\activate
   py -m pip install -r requirements.txt
   copy .env.example .env
5. .env in Editor öffnen. DISCORD_BOT_TOKEN und DASHBOARD_PASSWORD eintragen.
   FLASK_SECRET_KEY durch eine lange zufällige Zeichenfolge ersetzen.
6. Im Discord Developer Portal eine Application und einen Bot erstellen:
   https://discord.com/developers/applications
   Kopiere den Bot-Token in .env. Falls der Token bereits öffentlich geteilt wurde, resetten.
7. Bot über OAuth2 URL Generator mit den Scopes "bot" und Berechtigungen "View Channels" sowie "Connect" zum Server hinzufügen.
   Für Voice muss der Bot Zugriff auf den Ziel-Voice-Channel haben.
8. Starten:
   py app.py
9. Im Browser öffnen:
   http://127.0.0.1:5000
10. Mit DASHBOARD_PASSWORD anmelden. Bot starten, Server-ID und Voice-Channel-ID eintragen und verbinden.

B) ONLINE HOSTEN MIT GITHUB + RENDER
1. Erstelle ein privates GitHub-Repository.
2. Lade alle Projektdateien hoch, aber NIEMALS .env oder den Bot-Token.
3. In Render: New + > Web Service > dein Repository auswählen.
4. Build Command: pip install -r requirements.txt
5. Start Command: gunicorn --workers 1 --threads 4 --timeout 120 app:app
6. In Render > Environment folgende Variablen setzen:
   DISCORD_BOT_TOKEN = dein offizieller Bot-Token
   DASHBOARD_PASSWORD = ein starkes, eigenes Passwort
   FLASK_SECRET_KEY = lange zufällige Zeichenfolge
   GUILD_ID = deine Server-ID
   VOICE_CHANNEL_IDS = Voice-Channel-IDs, mit Komma getrennt
7. Deploy starten. Danach die Render-URL öffnen und einloggen.

SICHERHEIT
- Für eine öffentlich erreichbare Website ist ein starkes Passwort zwingend.
- Keine Tokens in Screenshots, GitHub oder Nachrichten posten.
- Bei einem Token-Leak: Discord Developer Portal öffnen und Bot-Token resetten.
- Render kann Webdienste bei kostenlosen Plänen nach Inaktivität schlafen legen; ein Voice-Bot braucht einen dauerhaft laufenden Prozess. Prüfe daher den aktuellen Tarif und die Verfügbarkeit von persistenten Diensten.
- Diese einfache Login-Lösung ist ein Starter für private Nutzung. Für mehrere Nutzer oder sensible Steuerung OAuth/Discord-Login, CSRF-Schutz, HTTPS und Rate-Limits ergänzen.
